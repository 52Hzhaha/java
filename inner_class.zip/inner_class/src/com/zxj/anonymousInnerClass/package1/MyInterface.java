package com.zxj.anonymousInnerClass.package1;

/**
 * 创建MyInterface接口
 */
public interface MyInterface {
    void sayHello();
}
