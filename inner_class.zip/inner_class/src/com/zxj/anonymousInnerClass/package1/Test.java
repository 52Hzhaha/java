package com.zxj.anonymousInnerClass.package1;

public class Test {
    public static void main(String[] args) {
        /**
         * 创建实现MyInterface接口的匿名内部类
         */
        MyInterface myInterface = new MyInterface() {
            @Override
            public void sayHello() {
                System.out.println("Hello everyone!");
            }
        };

        /**
         * 使用匿名内部类
         */
        myInterface.sayHello();
    }
}
