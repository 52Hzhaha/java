package com.zxj.anonymousInnerClass.package2;

/**
 * 创建MyClass类
 */
public class MyClass {

    public void sayHello(){
        System.out.println("Hello everyone!");
    }

}
