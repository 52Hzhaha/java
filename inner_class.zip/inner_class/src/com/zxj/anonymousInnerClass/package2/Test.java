package com.zxj.anonymousInnerClass.package2;

public class Test {
    public static void main(String[] args) {
        /**
         * 创建继承MyClass类的匿名内部类
         */
        MyClass myClass = new MyClass() {
            /**
             * 覆写父类方法
             */
            @Override
            public void sayHello() {
                System.out.println("Hello!");
            }
        };

        /**
         * 使用匿名内部类
         */
        myClass.sayHello();
    }
}
