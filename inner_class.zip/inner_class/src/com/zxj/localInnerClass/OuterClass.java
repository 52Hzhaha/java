package com.zxj.localInnerClass;

/**
 * 外部类
 */
public class OuterClass {

    public void outer(){
        /**
         * 局部内部类
         */
        class InnerClass{
            public void inner(){
                System.out.println("局部内部类");
            }
        }

        /**
         * 使用局部内部类
         */
        InnerClass innerClass = new InnerClass();
        innerClass.inner();
    }

}
