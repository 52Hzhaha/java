package com.zxj.localInnerClass;

public class Test {

    public static void main(String[] args) {
        OuterClass outerClass = new OuterClass();
        outerClass.outer();
    }

}
