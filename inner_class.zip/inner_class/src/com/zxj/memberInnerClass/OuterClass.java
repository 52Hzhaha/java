package com.zxj.memberInnerClass;

/**
 * 外部类
 */
public class OuterClass {
    private String privateVar = "private成员";
    public static String staticVar = "静态成员";

    /**
     * 成员内部类
     */
    class InnerClass{
        public void inner(){
            // 在成员内部类中，访问外部类的private成员
            System.out.println("外部类的private成员是：" + privateVar);
            // 在成员内部类中，访问外部类的静态成员
            System.out.println("外部类的静态成员是：" + staticVar);
        }
    }

    public InnerClass getInnerClass(){
        return new InnerClass();
    }

}
