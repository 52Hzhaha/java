package com.zxj.memberInnerClass;

public class Test {
    public static void main(String[] args) {
        OuterClass outerClass = new OuterClass();
        /**
         * 使用成员内部类
         */

        // 第一种方式
        OuterClass.InnerClass innerClass1 = outerClass.new InnerClass();// 必须通过外部类对象来创建内部类对象
        innerClass1.inner();

        // 第二种方式
        OuterClass.InnerClass innerClass2 = outerClass.getInnerClass();
        innerClass2.inner();
    }
}
