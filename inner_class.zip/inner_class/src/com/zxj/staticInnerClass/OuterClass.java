package com.zxj.staticInnerClass;

/**
 * 外部类
 */
public class OuterClass {

    /**
     * 静态内部类
     */
    static class InnerClass {
        public void inner(){
            System.out.println("静态内部类");
        }
    }
}
