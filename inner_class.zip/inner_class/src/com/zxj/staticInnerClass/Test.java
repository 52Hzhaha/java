package com.zxj.staticInnerClass;

public class Test {
    public static void main(String[] args) {
        // 创建静态内部类
        OuterClass.InnerClass innerClass = new OuterClass.InnerClass();
        innerClass.inner();
    }
}
