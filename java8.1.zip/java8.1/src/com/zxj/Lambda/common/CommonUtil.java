package com.zxj.Lambda.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

/**
 * 数据结构的操作工具类
 */
public class CommonUtil {
    /**
     * 遍历Integer类型的List并打印
     * @param list
     */
    public static void printIntegerList(List<Integer> list){
        Iterator<Integer> iterator = list.iterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }

    /**
     * 遍历Employee类型的List并打印
     * @param list
     */
    public static void printEmployeeList(List<Employee> list){
        Iterator<Employee> iterator = list.iterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }

    public static List<Employee> getEmployees(){
        List<Employee> employees = Arrays.asList(
                new Employee("张三", 40, 9999.99),
                new Employee("李四", 38, 8888.88),
                new Employee("王五", 36, 4444.44),
                new Employee("赵六", 30, 3333.33),
                new Employee("田七", 28, 2222.22)
        );
        return employees;
    }

    /**
     * 将字符串中一个个字符提取出来，放到集合list中，再将这个集合list转换成一个流。
     * @param str
     * @return
     */
    public static Stream<Character> filterCharacter(String str){
        List<Character> list = new ArrayList<>();

        // String的toCharArray()方法，用于将字符串转换成字符数组
        for(Character character : str.toCharArray()){
            list.add(character);
        }
        return list.stream();
    }
}
