package com.zxj.Lambda.package1;

import com.zxj.Lambda.common.CommonUtil;
import org.junit.Before;
import org.junit.Test;
import java.util.*;
/**
 * 测试类
 */
public class TestAnonymousInnerClassAndLambda {

    List<Integer> list = new ArrayList<Integer>();

    @Before
    public void before(){
        list.add(1);
        list.add(3);
        list.add(2);
        list.add(4);
    }

    /**
     * 使用匿名内部类对List进行排序
     */
    @Test
    public void anonymousInnerClass(){
        // 使用匿名内部类创建一个比较器
        Comparator<Integer> comparator = new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return Integer.compare(o1, o2);
            }
        };

        // 使用Collections工具类的sort方法对list中的元素进行排序
        Collections.sort(list, comparator);

        // 遍历list
        CommonUtil.printIntegerList(list);

    }

    /**
     * 使用Lambda表达式对List进行排序
     */
    @Test
    public void lambda(){
        // 使用Lambda表达式创建一个比较器
        Comparator<Integer> comparator = (x, y) -> Integer.compare(x, y);
        Collections.sort(list, comparator);
        CommonUtil.printIntegerList(list);
    }


}
