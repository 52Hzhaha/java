package com.zxj.Lambda.package2.useAnonymousInnerClass;

/**
 * 匿名内部类所需接口
 */
public interface MyFilter<T> {
    boolean filter(T t);
}
