package com.zxj.Lambda.package2.useIf;

import com.zxj.Lambda.common.Employee;
import com.zxj.Lambda.common.CommonUtil;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 测试类
 */
public class TestUseIf {

    List<Employee> employees = null;

    @Before
    public void before(){
        employees = CommonUtil.getEmployees();
    }

    /**
     * 根据年龄过滤的方法
     * @param employees
     * @return
     */
    public List<Employee> filterAgeByIf(List<Employee> employees){
        List<Employee> emps = new ArrayList<>();
        for (Employee employee : employees){
            if(employee.getAge() > 35){
                emps.add(employee);
            }
        }
        return emps;
    }

    /**
     * 需求：获取当前公司中，员工年龄大于35的员工信息。
     */
    @Test
    public void test1(){
        List<Employee> emps = filterAgeByIf(employees);
        CommonUtil.printEmployeeList(emps);
    }

    /**
     * 根据工资过滤的方法
     * @param employees
     * @return
     */
    public List<Employee> filterSalaryByIf(List<Employee> employees){
        List<Employee> emps = new ArrayList<>();
        for (Employee employee : employees){
            if(employee.getSalary() > 5000){
                emps.add(employee);
            }
        }
        return emps;
    }

    /**
     * 需求：获取当前公司中，工资大于5000的员工信息。
     */
    @Test
    public void test2(){
        List<Employee> emps = filterSalaryByIf(employees);
        CommonUtil.printEmployeeList(emps);
    }

}
