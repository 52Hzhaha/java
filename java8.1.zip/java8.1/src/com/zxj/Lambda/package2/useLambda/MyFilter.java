package com.zxj.Lambda.package2.useLambda;

/**
 * Lambda所需接口
 */
public interface MyFilter<T> {
    boolean filter(T t);
}
