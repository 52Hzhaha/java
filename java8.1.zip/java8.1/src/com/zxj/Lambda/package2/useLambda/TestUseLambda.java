package com.zxj.Lambda.package2.useLambda;

import com.zxj.Lambda.common.CommonUtil;
import com.zxj.Lambda.common.Employee;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * 测试类
 */
public class TestUseLambda {

    List<Employee> employees = null;

    @Before
    public void before(){
        employees = CommonUtil.getEmployees();
    }

    /**
     * 过滤方法
     * @param employees
     * @param myFilter
     * @return
     */
    public List<Employee> filter(List<Employee> employees, MyFilter<Employee> myFilter){
        List<Employee>  emps = new ArrayList<>();
        for (Employee employee : employees){
            if(myFilter.filter(employee)){
                emps.add(employee);
            }
        }
        return emps;
    }

    /**
     * 需求：获取当前公司中，员工年龄大于35的员工信息
     */
    @Test
    public void test1() {
        List<Employee> emps = filter(employees, (employee) -> employee.getAge() > 35);
        CommonUtil.printEmployeeList(emps);
    }

    /**
     * 需求：获取当前公司中，工资大于5000的员工信息。
     */
    @Test
    public void test2() {
        List<Employee> emps = filter(employees, (employee) -> employee.getSalary() > 5000);
        CommonUtil.printEmployeeList(emps);
    }

}
