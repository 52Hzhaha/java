package com.zxj.Lambda.package2.useStrategy;

import com.zxj.Lambda.common.Employee;

/**
 * 根据年龄过滤的具体策略类
 */
public class FilterEmployeeByAge implements MyStrategy<Employee> {
    @Override
    public boolean filter(Employee employee) {
        return employee.getAge() > 35;
    }
}
