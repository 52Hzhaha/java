package com.zxj.Lambda.package2.useStrategy;

import com.zxj.Lambda.common.Employee;

/**
 * 根据工资过滤的具体策略类
 */
public class FilterEmployeeBySalary implements MyStrategy<Employee> {
    @Override
    public boolean filter(Employee employee) {
        return employee.getSalary() > 5000;
    }
}
