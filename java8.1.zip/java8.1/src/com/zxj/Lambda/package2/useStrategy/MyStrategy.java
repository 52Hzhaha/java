package com.zxj.Lambda.package2.useStrategy;

/**
 * 策略接口
 */
public interface MyStrategy<T> {

    boolean filter(T t);

}
