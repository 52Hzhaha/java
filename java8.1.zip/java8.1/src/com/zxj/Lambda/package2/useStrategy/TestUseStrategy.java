package com.zxj.Lambda.package2.useStrategy;

import com.zxj.Lambda.common.Employee;
import com.zxj.Lambda.common.CommonUtil;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.List;

/**
 * 测试类
 */
public class TestUseStrategy {

    List<Employee> employees = null;

    @Before
    public void before(){
        employees = CommonUtil.getEmployees();
    }

    /**
     * 过滤方法，根据具体策略对employees进行过滤
     * @param employees
     * @param myStrategy
     * @return
     */
    public List<Employee> filter(List<Employee> employees, MyStrategy<Employee> myStrategy){
        List<Employee>  emps = new ArrayList<>();
        for (Employee employee : employees){
            if(myStrategy.filter(employee)){
                emps.add(employee);
            }
        }
        return emps;
    }

    /**
     * 获取当前公司中，员工年龄大于35的员工信息。
     */
    @Test
    public void test1(){
        List<Employee> emps = filter(employees, new FilterEmployeeByAge());
        CommonUtil.printEmployeeList(emps);
    }

    /**
     * 获取当前公司中，工资大于5000的员工信息。
     */
    @Test
    public void test2(){
        List<Employee> emps = filter(employees, new FilterEmployeeBySalary());
        CommonUtil.printEmployeeList(emps);
    }

}
