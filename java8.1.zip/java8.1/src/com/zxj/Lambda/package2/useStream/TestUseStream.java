package com.zxj.Lambda.package2.useStream;

import com.zxj.Lambda.common.CommonUtil;
import com.zxj.Lambda.common.Employee;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

/**
 * 测试类
 */
public class TestUseStream {

    List<Employee> employees = null;

    @Before
    public void before(){
        employees = CommonUtil.getEmployees();
    }

    /**
     * 使用Stream流 + 方法引用，执行过滤操作
     */
    @Test
    public void test(){
        /**
         * 获取当前公司中，员工年龄大于35的员工信息。
         */
        employees.stream()
                .filter((e) -> e.getAge() > 35)// Stream流的filter方法
                .forEach(System.out::println);// System.out::println：方法引用


        /**
         * 获取当前公司中，工资大于5000的员工信息。
         */
        employees.stream()
                .filter((e) -> e.getSalary() > 5000)
                .forEach(System.out::println);

    }
}
