package com.zxj.Lambda.package3;

import org.junit.Test;

import java.util.function.Function;

/**
 * 数组引用测试类
 */
public class TestArrayRef {

    /**
     * 需求：创建一个长度为10的String数组
     */
    @Test
    public void test(){
        /**
         * 使用匿名内部类
         */
        Function<Integer, String[]> function1 = new Function<Integer, String[]>() {
            @Override
            public String[] apply(Integer x) {
                return new String[x];
            }
        };
        String[] strArray1 = function1.apply(10);
        System.out.println(strArray1.length);

        /**
         * 使用Lambda表达式，Lambda体中不使用数组引用
         */
        Function<Integer, String[]> function2 = (x) -> new String[x];
        String[] strArray2 = function2.apply(10);
        System.out.println(strArray2.length);

        /**
         * 使用Lambda表达式，Lambda体中使用数组引用
         */
        Function<Integer, String[]> function3 = String[]::new;
        String[] strArray3 = function3.apply(10);
        System.out.println(strArray3.length);
    }
}
