package com.zxj.Lambda.package3;

import com.zxj.Lambda.common.Employee;
import org.junit.Test;

import java.util.function.Function;
import java.util.function.Supplier;

/**
 * 构造器引用测试类
 */
public class TestConstructorRef {
    /**
     * 需求：创建一个空的Employeee对象
     */
    @Test
    public void test1(){

        /**
         * 使用匿名内部类
         */
        Supplier<Employee> supplier1 = new Supplier<Employee>() {
            @Override
            public Employee get() {
                return new Employee();
            }
        };
        Employee employee1 = supplier1.get();
        System.out.println(employee1);

        /**
         * Lambda表达式，Lambda体中不使用构造器引用
         * Supplier供给型接口，get()方法，参数为空，返回一个类型为T的对象，所以Supplier
         * 的作用是产生一个对象。
         */
        Supplier<Employee> supplier2 = () -> new Employee();
        Employee employee2 = supplier2.get();
        System.out.println(employee2);

        /**
         * Lambda表达式，Lambda体中使用构造器引用
         */
        Supplier<Employee> supplier3 = Employee::new;
        Employee employee3 = supplier3.get();
        System.out.println(employee3);

    }

    /**
     * 创建一个员工编号为1的Employee对象
     */
    @Test
    public void test2(){
        /**
         * 使用匿名内部类
         */
        Function<Integer, Employee> function1 = new Function<Integer, Employee>() {
            @Override
            public Employee apply(Integer x) {
                return new Employee(x);
            }
        };
        Employee employee1 = function1.apply(1);
        System.out.println(employee1);

        /**
         * Lambda表达式，Lambda体中不使用构造器引用
         */
        Function<Integer, Employee> function2 = (x) -> new Employee(x);
        Employee employee2 = function2.apply(1);
        System.out.println(employee2);


        /**
         * Lambda表达式，Lambda体中使用构造器引用
         */
        Function<Integer, Employee> function3 = Employee::new;
        Employee employee3 = function3.apply(2);
        System.out.println(employee3);
    }

}
