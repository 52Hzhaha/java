package com.zxj.Lambda.package3;

import com.zxj.Lambda.common.Employee;
import org.junit.Test;
import java.util.Comparator;
import java.util.function.BiPredicate;
import java.util.function.Supplier;

/**
 * 方法引用测试类
 */
public class TestMethodRef {
    /**
     * 语法格式1：对象::实例方法名
     * 需求：创建一个员工对象，获取员工姓名。
     */
    @Test
    public void test1(){
        Employee employee = new Employee("张三", 25, 30000l);
        /**
         * 匿名内部类
         */
        Supplier<String> supplier1 = new Supplier<String>() {
            @Override
            public String get() {
                return employee.getName();
            }
        };
        String name1 = supplier1.get();
        System.out.println(name1);

        /**
         * Lambda表达式，Lambda体中不使用方法引用
         */
        Supplier<String> supplier2 = () -> employee.getName();
        String name2 = supplier2.get();
        System.out.println(name2);

        /**
         * Lambda表达式，Lambda体中使用方法引用，对象::实例方法名
         */
        Supplier<String> supplier3 = employee::getName;
        String name3 = supplier3.get();
        System.out.println(name3);
    }

    /**
     * 需求：比较两个Integer类型的值的大小
     */
    @Test
    public void test2(){
        /**
         * 匿名内部类
         */
        Comparator<Integer> comparator1 = new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return Integer.compare(o1, o2);
            }
        };
        /**
         * Integer.compare(o1, o2)，如果第一个比第二个大，返回1，如果第一个比第二个小，返回-1。
         */
        int result1 = comparator1.compare(2, 1);
        System.out.println(result1);

        /**
         * Lambda表达式，Lambda体中不使用方法引用
         */
        Comparator<Integer> comparator2 = (x, y) -> Integer.compare(x, y);
        int result2 = comparator2.compare(2,1);
        System.out.println(result2);

        /**
         * Lambda表达式，Lambda体中使用方法引用，类::静态方法名
         */
        Comparator<Integer> comparator3 = Integer::compare;
        int result3 = comparator3.compare(2,1);
        System.out.println(result3);
    }

    /**
     *
     */
    @Test
    public void test3(){
        /**
         * 匿名内部类
         */
        BiPredicate<String, String> biPredicate1 = new BiPredicate<String, String>() {
            @Override
            public boolean test(String s1, String s2) {
                return s1.equals(s2);
            }
        };
        boolean result1 = biPredicate1.test("Hello World!", "Hello World!");
        System.out.println(result1);

        /**
         * Lambda表达式，Lambda体中不使用方法引用
         */
        BiPredicate<String, String> biPredicate2 = (x, y) -> x.equals(y);
        boolean result2 = biPredicate2.test("Hello World!", "Hello World!");
        System.out.println(result2);

        /**
         * Lambda表达式，Lambda体中使用方法引用，类::静态方法名
         */
        BiPredicate<String, String> biPredicate3 = String::equals;
        boolean result3 = biPredicate3.test("Hello World!", "Hello World?");
        System.out.println(result3);
    }
}
