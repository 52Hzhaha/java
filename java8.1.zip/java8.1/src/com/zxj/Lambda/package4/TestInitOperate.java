package com.zxj.Lambda.package4;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/**
 * 测试初始操作
 */
public class TestInitOperate {
    /**
     * 集合作为Stream的数据源，使用集合的stream()方法和parallelStream()方法创建流。
     */
    @Test
    public void test1(){
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        // 串行流
        Stream<Integer> stream = list.stream();
        // 并行流
        Stream<Integer> parallelStream = list.parallelStream();
        // TODO ：对流对象执行操作
    }

    /**
     * 数组作为Stream的数据源，使用Arrays类的静态方法stream()创建流。
     */
    @Test
    public void test2(){
        Integer nums[] = {1, 2, 3, 4, 5};
        Stream<Integer> stream = Arrays.stream(nums);
    }

    /**
     * 使用Stream类的of方法创建流。
     */
    @Test
    public void test3(){
        Stream<Integer> stream = Stream.of(1, 2, 3);
    }

    /**
     * 使用Stream类的iterate方法创建流。
     */
    @Test
    public void test4(){
        /**
         * 从0开始，无限制地执行加2操作。
         */
        Stream<Integer> stream = Stream.iterate(0, (x) -> x + 2);

        /**
         * 如果不想让其无限制执行下去，可以加上limit方法限制一下
         * limit(10)，此时从0开始，只会执行10次加2操作。
         */
        Stream<Integer> newStream =  stream.limit(10);
    }

    /**
     * 使用Stream类的generate方法创建流。
     */
    @Test
    public void test5(){
        /**
         * 无限制地创建随机数
         */
        Stream.generate(() -> Math.random());
    }
}
