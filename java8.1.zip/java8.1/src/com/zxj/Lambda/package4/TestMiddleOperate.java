package com.zxj.Lambda.package4;

import com.zxj.Lambda.common.CommonUtil;
import com.zxj.Lambda.common.Employee;
import org.junit.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 测试中间操作
 */
public class TestMiddleOperate {
    List<Employee> employees = Arrays.asList(
            new Employee("张三", 40, 9999.99),
            new Employee("李四", 38, 8888.88),
            new Employee("王五", 36, 5000.44),
            new Employee("赵六", 30, 3333.33),
            new Employee("田七", 28, 2222.22),
            new Employee("田七", 28, 2222.22),
            new Employee("田七", 28, 2222.22)
    );

    List<String> list = Arrays.asList("aaa", "ccc", "bbb", "eee", "ddd");

    /**
     * filter(Predicate p)
     */
    @Test
    public void test1(){
        Stream<Employee> stream = employees.stream()
                .filter((employee) -> employee.getAge()>25);

        // 执行foreach终止操作，遍历stream，看一下是否过滤成功
        stream.forEach(System.out::println);
    }

    /**
     * distinct()
     */
    @Test
    public void test2(){
        // 注意：要想去除重复元素，需要重写Employee的hashCode方法和equals方法。
        employees.stream()
                .distinct()
                .forEach(System.out::println);
    }

    /**
     * limit()
     */
    @Test
    public void test3(){
        /**
         * 先过滤，然后对过滤得到的结果执行limit(2)操作，取前两个元素
         */
        Stream<Employee> stream = employees.stream()
                .filter((employee) -> employee.getSalary() > 5000)
                .limit(2);
        stream.forEach(System.out::println);
    }

    /**
     * skip(long n)
     */
    @Test
    public void test4(){
        /**
         *
         * 先过滤，然后对过滤得到的结果执行skip(2)操作，扔掉前两个元素
         */
        Stream<Employee> stream = employees.stream()
                .filter((employee) -> employee.getSalary() > 5000)
                .skip(2);
        stream.forEach(System.out::println);
    }

    /**
     * map(Function f)
     */
    @Test
    public void test5(){
        String[] words = new String[]{"Hello","World"};
        List<String[]> list = Arrays.stream(words)
                .map(word -> word.split(""))
                .collect(Collectors.toList());
        list.forEach(System.out::print);
    }

    /**
     * flatMap(Function f)
     */
    @Test
    public void test6(){
        String[] words = new String[]{"Hello","World"};
        List<String> list =  Arrays.stream(words)
                .flatMap(word -> Stream.of(word.split("")))
                .collect(Collectors.toList());
        list.forEach(System.out::print);
    }

    /**
     * sort()
     */
    @Test
    public void test7(){
        List<String> list = Arrays.asList("aaa", "ccc", "bbb", "eee", "ddd");

        list.stream()
                .sorted()
                .forEach(System.out::println);
    }

    /**
     * sorted(Comparator comparator)
     */
    @Test
    public void test8(){
        // 源数据准备
        List<Employee> employees = Arrays.asList(
                new Employee("张三", 40, 9999.99),
                new Employee("李四", 38, 8888.88),
                new Employee("王五", 36, 5000.44),
                new Employee("赵六", 30, 3333.33),
                new Employee("田七", 28, 2222.22),
                new Employee("田七", 28, 2222.22),
                new Employee("田七", 28, 2222.22)
        );

        /**
         * 自定义排序，需要创建自定义一个Comparator，有两种方式，方式一是使用匿名内部类创建一个Comparator对象，
         * 然后在Stream流中使用这个对象对employees进行定制排序，方式二是在Stream流的sorted方法中，
         * 使用Lambda表达式创建一个Comparator。
         */
        // 方式一
        Comparator<Employee> comparator = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                /**
                 * 定制的排序规则：先按照年龄排序，如果年龄一样，就按照姓名排序。
                 */
                if (e1.getAge().equals(e2.getAge())) {
                    return e1.getName().compareTo(e2.getName());
                } else {
                    return e1.getAge().compareTo(e2.getAge());
                }
            }
        };

        employees.stream()
                .sorted(comparator)
                .forEach(System.out::println);

        // 方式二
        employees.stream()
                .sorted((e1, e2) ->{
                    if (e1.getAge().equals(e2.getAge())) {
                        return e1.getName().compareTo(e2.getName());
                    } else {
                        return e1.getAge().compareTo(e2.getAge());
                    }
                }).forEach(System.out::println);
    }
}
