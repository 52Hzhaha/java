package com.zxj.Lambda.package4;

import com.zxj.Lambda.common.Employee;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 测试终止操作
 */
public class TestTerminateOperate {

    List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

    List<Employee> employees = Arrays.asList(
            new Employee("张三", 40, 9999.99, Employee.Status.FREE),
            new Employee("李四", 38, 8888.88, Employee.Status.BUSY),
            new Employee("王五", 36, 5000.44, Employee.Status.VOCATION),
            new Employee("赵六", 30, 3333.33, Employee.Status.FREE),
            new Employee("田七", 28, 2222.22, Employee.Status.BUSY),
            new Employee("田七", 28, 2222.22, Employee.Status.BUSY),
            new Employee("田七", 28, 2222.22, Employee.Status.BUSY)
    );

    /**
     * allMatch(Predicate p)
     */
    @Test
    public void test1(){
        boolean result = employees.stream()
                .allMatch((employee) -> employee.getStatus().equals(Employee.Status.BUSY));// false
        System.out.println(result);
    }

    /**
     * anyMatch(Predicate p)
     */
    @Test
    public void test2(){
        boolean result = employees.stream()
                .anyMatch((employee) -> employee.getStatus().equals(Employee.Status.BUSY));// true
        System.out.println(result);
    }

    /**
     * noneMatch(Predicate p)
     */
    @Test
    public void test3(){
        boolean result = employees.stream()
                .anyMatch((employee) -> employee.getStatus().equals(Employee.Status.BUSY));// true
        System.out.println(result);
    }

    /**
     * findFirst()
     */
    @Test
    public void test4(){
        Optional<Employee> optional = employees.stream()
                .sorted((e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary()))
                .findFirst();
        Employee employee = optional.orElse(new Employee());
        System.out.println(employee);
    }

    /**
     * findAny(): 返回当前流中的任意元素
     * 需求：找出处于空闲状态的任意一个员工
     * 首先使用filter方法过滤出处于空闲状态的员工，然后从其中随便选择一位。
     */
    @Test
    public void test5(){
        Optional<Employee> optional = employees.stream()
                .filter((employee) -> employee.getStatus().equals(Employee.Status.FREE))
                .findAny();
        Employee employee = optional.orElse(new Employee());
        System.out.println(employee);
    }

    /**
     * count()：计算employees中员工的数量
     */
    @Test
    public void test6(){
        long count = employees.stream()
                .count();
        System.out.println(count);
    }

    /**
     * max()
     * 返回工资最高的员工的信息
     */
    @Test
    public void test7(){
        Optional<Employee> optional = employees.stream()
                .max((e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary()));
        System.out.println(optional.orElse(new Employee()));
    }

    /**
     * min()
     * 返回工资最低的员工的工资
     */
    @Test
    public void test8(){
        Optional<Double> optional = employees.stream()
                .map((employee) -> employee.getSalary())
                .min(Double::compare);
        System.out.println(optional.get());
    }

    /**
     * 需求：将集合list中的元素，反复累加得到一个总和
     */
    @Test
    public void test9(){
        Integer sum = list.stream()
                .reduce(0, (x, y) -> x + y);
        System.out.println(sum);
    }


    /**
     * 需求：把当前员工的名字都提取出来，并放到一个List集合中去。
     */
    @Test
    public void test10(){
        List<String> list = employees.stream()
                .map(Employee::getName)
                .collect(Collectors.toList());
        list.forEach(System.out::println);
    }

    /**
     * 需求：计算employees中一共有多少个员工
     */
    @Test
    public void test11(){
        List<String> list = employees.stream()
                .map(Employee::getName)
                .collect(Collectors.toList());
        list.forEach(System.out::println);
    }

    /**
     * 需求：计算employees中员工工资的平均值
     */
    @Test
    public void test12(){
        Double average = employees.stream()
                .collect(Collectors.averagingDouble(Employee::getSalary));
        System.out.println(average);
    }

    /**
     * 需求：计算employees中所有员工工资的和
     */
    @Test
    public void test13(){
        Double sum = employees.stream()
                .collect(Collectors.summingDouble(Employee::getSalary));
        System.out.println(sum);
    }

    /**
     * 需求：计算employees中员工工资最低的工资是多少。
     */
    @Test
    public void test14(){
        Optional<Double> optional = employees.stream()
                .map(Employee::getSalary)
                .collect(Collectors.minBy(Double::compare));
        System.out.println(optional.get());
    }

    /**
     * 需求：按照状态status，对employees中的数据进行分组。
     */
    @Test
    public void test15(){
        Map<Employee.Status, List<Employee>> map = employees.stream()
                .collect(Collectors.groupingBy(Employee::getStatus));
        System.out.println(map);
    }

    /**
     * 需求：对employees进行多级分组，先按照状态分组，然后按照年龄自定义分组(如果年龄小于35，
     * 属于青年，如果年龄大于35，小于等于50，属于中年，如果年龄大于50，属于老年)
     * map的key：状态
     * map的value：根据状态分组的结果
     */
    @Test
    public void test16(){
        Map<Employee.Status, List<Employee>> map = employees.stream()
                .collect(Collectors.groupingBy(Employee::getStatus));
        System.out.println(map);
    }

    /**
     * 需求：对employees中的所有员工进行分区，工资大于8000的为一区，小于等于8000的为一区。
     */
    @Test
    public void test17(){
        Map<Boolean, List<Employee>> map = employees.stream()
                .collect(Collectors.partitioningBy((employee) -> employee.getSalary() > 8000));
        System.out.println(map);
    }

    /**
     * 需求：连接employees中员工的姓名，成为一个字符串。
     */
    @Test
    public void test18(){
        String str = employees.stream()
                .map(Employee::getName)
                .collect(Collectors.joining());
        System.out.println(str);
    }

    /**
     * 需求：连接employees中员工的姓名，成为一个字符串，字符串中每个员工姓名中间加一个逗号。
     */
    @Test
    public void test19(){
        String str = employees.stream()
                .map(Employee::getName)
                .collect(Collectors.joining(","));
        System.out.println(str);
    }

    /**
     * 需求：连接employees中员工的姓名，成为一个字符串，符串中每个员工姓名中间加一个逗号，并且字符串的开头和结尾分别有"==="。
     */
    @Test
    public void test20(){
        String str = employees.stream()
                .map(Employee::getName)
                .collect(Collectors.joining(",","===","==="));
        System.out.println(str);
    }
}
