package com.zxj.package1;

public interface MyDefaultInterface {

    /**
     * 默认方法
     */
    default String getName(){
        return "哈哈哈";
    }

}
