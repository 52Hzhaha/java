package com.zxj.package10.repeatAnnotation.after;

import org.junit.Test;

import java.lang.reflect.Method;

/**
 * 重复注解
 */
public class TestAnnotation {

    /**
     * 此时不报红了，这是由于添加了@MyAnnotations，从而可以使用重复注解了。
     */
    @MyAnnotation("Hello")
    @MyAnnotation("World")
    public void show(){

    }

    @Test
    public void test() throws NoSuchMethodException {
        Class<TestAnnotation> clazz = TestAnnotation.class;
        Method method = clazz.getMethod("show");

        MyAnnotation[] mas = method.getAnnotationsByType(MyAnnotation.class);

        for (MyAnnotation myAnnotation : mas){
            System.out.println(myAnnotation.value());
        }

    }

}
