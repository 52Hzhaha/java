package com.zxj.package10.repeatAnnotation.before;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

/**
 * 重复注解：是自定义的注解
 * @Target：表示注解的目标，即你自定义的注解是可以修饰类、方法（METHOD）、还是属性（FIELD）还是参数（PARAMETER）等等
 * @Retention：：表示注解的生命周期，当前指定的生命周期是RUNTIME（运行时）。
 */
@Target({TYPE, FIELD, METHOD, PARAMETER, CONSTRUCTOR, LOCAL_VARIABLE})
@Retention(RetentionPolicy.RUNTIME)
public @interface MyAnnotation {

    String value() default "可重复注解";

}
