package com.zxj.package10.repeatAnnotation.before;

/**
 * 重复注解
 */
public class TestAnnotation {

    /**
     * 两个@MyAnnotation都报红，说明此时不允许重复注解，原因是我们忽略了使用重复注解的前提。
     * 要想使用重复注解，需要创建一个注解的容器类，即注解的注解，见after包。
     */
//    @MyAnnotation("Hello")
//    @MyAnnotation("World")
//    public void show(){
//
//    }

}
