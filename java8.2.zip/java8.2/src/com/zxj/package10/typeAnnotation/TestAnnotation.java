package com.zxj.package10.typeAnnotation;

/**
 * 类型注解
 */
public class TestAnnotation {

    /**
     * 此时，自定义注解@MyAnnotation，可以应用在String这个类型上。
     * @param str
     */
    public void show(@MyAnnotation("abc") String str){

    }
}
