package com.zxj.package2;

public interface MyStaticInterface {
    /**
     * 静态方法
     */
    static void show(){
        System.out.println("接口中的静态方法");
    }
}
