package com.zxj.package2;

public class TestStaticInterface {
    /**
     * 使用接口中的静态方法
     * @param args
     */
    public static void main(String[] args) {
        MyStaticInterface.show();
    }
}
