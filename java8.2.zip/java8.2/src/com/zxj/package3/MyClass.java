package com.zxj.package3;

/**
 * 父类
 */
public class MyClass {
    public String getName(){
        return "调用父类中的方法";
    }
}
