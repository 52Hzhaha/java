package com.zxj.package3;

/**
 * 接口
 */
public interface MyInterface {
    /**
     * 默认方法
     */
    default String getName(){
        return "调用接口中的方法";
    }
}
