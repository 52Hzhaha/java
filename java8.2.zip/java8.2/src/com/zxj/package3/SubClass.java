package com.zxj.package3;

/**
 * 子类
 */
public class SubClass extends MyClass implements MyInterface{

}
