package com.zxj.package4.conflict;

/**
 * 子类
 */
public class SubClass implements MyInterface1, MyInterface2 {

    /**
     * 方法冲突：getName方法是MyInterface1的getName方法，还是MyInterface2的getName方法。
     * @return
     */
    @Override
    public String getName() {
        return null;
    }
}
