package com.zxj.package4.solveConflict;

/**
 * 接口1
 */
public interface MyInterface1 {
    default String getName(){
        return "调用接口1中的方法";
    }
}
