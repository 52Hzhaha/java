package com.zxj.package4.solveConflict;

/**
 * 接口2
 */
public interface MyInterface2 {
    default String getName(){
        return "调用接口2中的方法";
    }
}
