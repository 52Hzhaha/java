package com.zxj.package4.solveConflict;

import com.zxj.package4.conflict.MyInterface1;
import com.zxj.package4.conflict.MyInterface2;

/**
 * 子类
 */
public class SubClass implements MyInterface1, MyInterface2 {
    @Override
    public String getName() {
        /**
         * 覆盖的时候，指定覆盖的是接口MyInterface1中的getName方法。
         */
        return MyInterface1.super.getName();
    }
}
