package com.zxj.package4.solveConflict;

/**
 * 测试类
 */
public class Test {
    @org.junit.Test
    public void test(){
        SubClass subClass = new SubClass();
        System.out.println(subClass.getName());
    }
}
