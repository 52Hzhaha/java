package com.zxj.package5;

/**
 * 国家
 */
public class Country {
    private String name;// 国家的名字
    private Flag flag;// 国家的国旗

    public Country(){

    }

    public Country(String name, Flag flag) {
        this.name = name;
        this.flag = flag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Flag getFlag() {
        return flag;
    }

    public void setFlag(Flag flag) {
        this.flag = flag;
    }
}
