package com.zxj.package5;

/**
 * 国旗
 */
public class Flag {
    private String colour;// 国旗的颜色

    public Flag(){

    }

    public Flag(String colour) {
        this.colour = colour;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }
}
