package com.zxj.package5;

/**
 * 人
 */
public class People {
    private String name;// 这个人的姓名
    private Country country;// 这个人所在的国家

    public People(){

    }

    public People(String name, Country country) {
        this.name = name;
        this.country = country;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }
}
