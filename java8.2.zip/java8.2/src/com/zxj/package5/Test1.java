package com.zxj.package5;

/**
 * 测试类
 */
public class Test1 {

    @org.junit.Test
    public void test(){
        /**
         * People对象
         */
        People people = new People("小明",new Country("中国", new Flag("red")));
        String colour = people.getCountry().getFlag().getColour();
        System.out.println("小明所在国家的国旗的颜色是：" + colour);
    }
}
