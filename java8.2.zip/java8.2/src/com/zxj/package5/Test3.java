package com.zxj.package5;

import java.util.Optional;

/**
 * 测试类
 */
public class Test3 {
    @org.junit.Test
    public void test(){
        /**
         * People对象
         */
        // peope对象非空的情况
//        People people = new People("小明",new Country("中国", new Flag("red")));
        // peope对象为空的情况
        People people = null;
        String colour = "";
        // 避免People对象为null，报空指针异常
        Optional<People> optional1 = Optional.ofNullable(people);
        People optionalPeople = optional1.orElse(new People());
        // 避免Country对象为null，报空指针异常
        Optional<Country> optional2 = Optional.ofNullable(optionalPeople.getCountry());
        Country optionalCountry = optional2.orElse(new Country());
        // 避免Flag对象为null，报空指针异常
        Optional<Flag> optional3 = Optional.ofNullable(optionalCountry.getFlag());
        Flag flag = optional3.orElse(new Flag());
        colour = flag.getColour();
        System.out.println("小明所在国家的国旗的颜色是：" + colour);
    }
}
