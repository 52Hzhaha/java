package com.zxj.package6;

import org.junit.Test;

import java.util.Optional;

/**
 * Optional测试类
 */
public class TestOptional {
    /**
     * Optional<T> Optional.of(T t)
     */
    @Test
    public void test1(){
        // of方法的参数是一个非空的实例
        Optional<Employee> optional1 = Optional.of(new Employee());
        Employee employee1 = optional1.get();
        System.out.println(employee1);

        // of方法的参数是null
        Optional<Employee> optional2 = Optional.of(null);
        Employee employee2 = optional2.get();
        System.out.println(employee2);
    }

    /**
     * Optional<T> Optional.ofNullable(T t)
     */
    @Test
    public void test2(){
        // ofNullable方法的参数是一个非空的实例
        Optional<Employee> optional1 = Optional.ofNullable(new Employee());
        System.out.println(optional1.get());

        // ofNullable方法的参数是null
        Optional<Employee> optional2 = Optional.ofNullable(null);
        System.out.println(optional2.get());
    }

    /**
     * Optional<T> Optional.empty()
     */
    @Test
    public void test3(){
        Optional optional = Optional.empty();
        System.out.println(optional.get());
    }

    /**
     * boolean isPresent()
     */
    @Test
    public void test4(){
        // 如果Optional实例里存储的是一个真实的实例，返回true
        Optional<Employee> optional1 = Optional.ofNullable(new Employee());
        System.out.println(optional1.isPresent());

        // 如果Optional实例里存储的是null，调用isPresent()方法会报空指针异常
        Optional<Employee> optional2 = Optional.of(null);
        System.out.println(optional2.isPresent());

        // 如果是一个空的Optional实例，返回false
        Optional optional3 = Optional.empty();
        System.out.println(optional3.isPresent());
    }

    /**
     * Optional<T> orElse(T t)
     */
    @Test
    public void test5(){
        /**
         * 如果Optional实例中有值，就返回该值，即new Employee("张三",18,2000)
         */
        Optional<Employee> optional1 = Optional.ofNullable(new Employee("张三",18,2000));
        System.out.println(optional1.orElse(new Employee()));

        /**
         * 否则返回我们传递给它的参数，即new Employee()
         */
        Optional<Employee> optional2 = Optional.empty();
        System.out.println(optional2.orElse(new Employee()));
    }

    /**
     * T get()
     */
    @Test
    public void test6(){
        /**
         * 如果Optional实例中有值，就返回该值，即new Employee("张三",18,2000)
         */
        Optional<Employee> optional1 = Optional.ofNullable(new Employee("张三",18,2000));
        System.out.println(optional1.get());

        /**
         * 否则抛出异常：NoSuchElementException
         */
        Optional<Employee> optional2 = Optional.empty();
        System.out.println(optional2.get());

        /**
         * 在使用get()方法时，为了避免异常，应该先验证Optional实例中是否有值。
         */
        Optional<Employee> optional3 = Optional.empty();
        if (optional3.isPresent()){
            System.out.println(optional3.get());
        }else{
            System.out.println("Optional实例是一个空实例");
        }
    }

    /**
     * Optional<U> map(Function<? super T,? extends U> mapper)
     */
    @Test
    public void test7(){
        Optional<Employee> employeeOptional = Optional.ofNullable(new Employee("张三",18,2000));
        /**
         * 使用map，将Optional实例中的Employee实例映射成Employee实例中的name字段。
         * 注意Function函数式接口中apply方法，返回值是employee.getName()，是String类型。
         */
        Optional<String> stringOptional = employeeOptional.map((employee) -> employee.getName());
        String name = stringOptional.get();
        System.out.println(name);
    }

    /**
     * Optional<U> flatMap(Function<? super T,Optional<U>> mapper)
     */
    @Test
    public void test8(){
        Optional<Employee> employeeOptional = Optional.ofNullable(new Employee("张三",18,2000));
        /**
         * 注意Function函数式接口中apply方法，返回值是Optional.of(employee.getName()，是Optional类型。
         */
        Optional<String> stringOptional = employeeOptional.flatMap((employee) -> Optional.of(employee.getName()));
        System.out.println(stringOptional.get());
    }

}
