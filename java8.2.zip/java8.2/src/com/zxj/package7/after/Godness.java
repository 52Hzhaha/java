package com.zxj.package7.after;

public class Godness {
    private String name;// 女神是一定有名字的，name不需要放在Optional里。

    public Godness(){

    }

    public Godness(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Godness{" +
                "name='" + name + '\'' +
                '}';
    }
}
