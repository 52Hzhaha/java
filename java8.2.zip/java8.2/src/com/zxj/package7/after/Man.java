package com.zxj.package7.after;

import java.util.Optional;

public class Man {

    /**
     * 将有可能为null的值放到Optional里。
      */
    // 1、如果这样写，Optional实例默认为null，那使用Optional也就没有意义了，后面操作Optional实例还是会报NPE。
//    private Optional<Godness> godness;// 等价于private Optional<Godness> godness = null;
    // 2、所以我们必须初始化一个Optional实例，哪怕Optional实例里面啥都没有。
    private Optional<Godness> godness = Optional.empty();

    /**
     * 定不为null的值不需要放在Optional里
     * 男人肯定都是有名字的，所以name不需要放在Optional里。
     */
    private String name;

    public Man(){

    }

    public Man(Optional<Godness> godness, String name) {
        this.godness = godness;
        this.name = name;
    }

    public Optional<Godness> getGodness() {
        return godness;
    }

    public void setGodness(Optional<Godness> godness) {
        this.godness = godness;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Man{" +
                "godness=" + godness +
                ", name='" + name + '\'' +
                '}';
    }
}
