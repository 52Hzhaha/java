package com.zxj.package7.after;

import java.util.Optional;

public class Test {

    /**
     * 现在的写法，使用Optional的orElse方法防止发生空指针，当男神心中没有女神时，
     * 就默认给其一个女神，赵丽颖。
     * @param man
     * @return
     */
    public String getGodnessName(Man man){
        Optional<Godness> optionalGodness = man.getGodness();
        // 如果男人心中有女神，godness就是这个女神，否则就是new Godness("赵丽颖")，肯定不会为null，所以不会报NPE。
        Godness godness = optionalGodness.orElse(new Godness("赵丽颖"));
        String godnessName = godness.getName();
        return godnessName;
    }

    @org.junit.Test
    public void test(){
        Man man1 = new Man();
        String godnessName1 = getGodnessName(man1);
        System.out.println(godnessName1);// 默认的女神：赵丽颖

        Man man2 = new Man(Optional.of(new Godness("杨幂")), "张三");
        String godnessName2 = getGodnessName(man2);// 女神：杨幂
        System.out.println(godnessName2);
    }
}
