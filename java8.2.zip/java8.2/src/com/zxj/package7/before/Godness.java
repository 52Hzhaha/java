package com.zxj.package7.before;

/**
 * 女神
 */
public class Godness {

    private String name;// 女神的名字

    public Godness(){

    }

    public Godness(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Godness{" +
                "name='" + name + '\'' +
                '}';
    }
}
