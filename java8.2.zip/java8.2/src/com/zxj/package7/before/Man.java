package com.zxj.package7.before;

/**
 * 男人
 */
public class Man {
    private Godness godness;// 男人心中的女神，不是每个男人心中都有女神，就是说当男人心中没有女神时，Man中的Godness可能为空(null)
    private String name;// 男人的名字

    public Man(){

    }

    public Man(Godness godness, String name) {
        this.godness = godness;
        this.name = name;
    }

    public Godness getGodness() {
        return godness;
    }

    public void setGodness(Godness godness) {
        this.godness = godness;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Man{" +
                "godness=" + godness +
                ", name='" + name + '\'' +
                '}';
    }
}
