package com.zxj.package7.before;

/**
 * 需求：获取一个男人心中女神的名字
 */
public class Test {

    /**
     * 没有非空判断，会报NPE。
     * @param man
     * @return
     */
    public String getGodnessName1(Man man){
        return man.getGodness().getName();
    }

    /**
     * 加上非空判断
     * @param man
     * @return
     */
    public String getGodnessName2(Man man){
        Godness godness = man.getGodness();
        if(godness != null){
            String godnessName = godness.getName();
            return godnessName;
        }
        return "赵丽颖";
    }

    /**
     * 在java8之前的写法，man.getGodness()为null，对null调用getName()方法，会报NPE。
     */
    @org.junit.Test
    public void test1(){
        Man man = new Man();// 创建一个男人，这个男人没有女神

        String godnessName1 = getGodnessName1(man);
        System.out.println(godnessName1);
    }

    /**
     * 在java8之前的写法，避免空指针的解决方案，加上非空判断防止空指针，此时不会报NPE了。
     */
    public void test2(){
        Man man = new Man();// 创建一个男人，这个男人没有女神
        String godnessName2 = getGodnessName2(man);
        System.out.println(godnessName2);
    }
}
