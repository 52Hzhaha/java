package com.zxj.package8.java7;

import java.util.concurrent.RecursiveTask;

/**
 * RecursiveAction和RecursiveTask的区别：
 * RecursiveAction没有返回值
 * RecursiveTask有返回值
 */
public class ForkJoinCalculate extends RecursiveTask<Long> {

    // 累加，从start加到end，sum = start + (start+1) + ... + end
    private long start;
    private long end;

    public ForkJoinCalculate(long start, long end){
        this.start = start;
        this.end = end;
    }

    /**
     * 拆分的临界值，
     * 比如我们想从1加到100亿，一半一半地拆，1到50亿，50亿到100亿，
     * 1到50亿，拆分成，1到25亿，25亿到50亿，
     * 1到25亿，拆分成，1到12.5亿，12.5亿到25亿
     * 。。。。直到拆分成1到10000，10000到20000。。。。
     *
     * 这些一半一半的就是一个一个线程，然后把它们分配给CPU就可以了。
     */
    private static final long THRESHOLD = 10000;

    @Override
    protected Long compute() {
        long length = end - start;

        // length <= THRESHOLD，表示到达临界值，到达临界值，我们就要开始加（join）。
        if(length <= THRESHOLD){
            long sum = 0;
            for(long i = start; i <= end; i++){
                sum += i;
            }
            return sum;
        }else{
            /**
             * 如果没有到达临界值，我们就要继续拆（fork），Recursive，翻译是递归的意思，Fork/Join的拆分就是不断地递归拆分，
             * 所以当拆分的时候，我们在ForkJoinCalculate里面又new一个ForkJoinCalculate（递归）。
             */

            // 拆分，fork
            long middle = (start + end) / 2;
            ForkJoinCalculate leftForkJoinCalculate = new ForkJoinCalculate(start, middle);
            leftForkJoinCalculate.fork();// 拆分父任务，leftForkJoinCalculate是拆出来的左边这一半的子任务，将其压入线程队列

            ForkJoinCalculate rightForkJoinCalculate = new ForkJoinCalculate(middle+1, end);
            rightForkJoinCalculate.fork();// 拆分父任务，rightForkJoinCalculate是拆出来的右边这一半的子任务，将其压入线程队列

            // 合并，join
            return leftForkJoinCalculate.join() + rightForkJoinCalculate.join();
        }

    }
}
