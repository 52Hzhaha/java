package com.zxj.package8.java7;

import org.junit.Test;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;

public class TestForkJoin {

    @Test
    public void test(){
        Instant start = Instant.now();// 开始时间戳

        ForkJoinPool forkJoinPool = new ForkJoinPool();
        // 执行0到1亿的累加
        ForkJoinTask<Long> forkJoinCalculate = new ForkJoinCalculate(0, 10000000000L);
        Long sum = forkJoinPool.invoke(forkJoinCalculate);
        System.out.println(sum);

        Instant end = Instant.now();// 结束时间戳

        // 100亿：638毫秒
        System.out.println("耗费时间为：" + Duration.between(start, end).toMillis());// 单位：毫秒
    }
}
