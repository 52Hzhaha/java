package com.zxj.package8.java8;

import java.time.Duration;
import java.time.Instant;
import java.util.stream.LongStream;

public class Test {

    @org.junit.Test
    public void test(){

        /**
         * LongStream.rangeClosed：生成一个LongStream流，流中数据从0到100亿。
         * sequential()：将流转换成串行流
         * parallel()：将流转换成并行流
         * reduce：对流中的数据执行累加操作，如果上面将流转换成了并行流，执行reduce操作会更快，耗时更短。
         */

        /**
         * 串行流：sequential()
         */
        Instant start1 = Instant.now();// 开始时间戳
        long sum1 = LongStream.rangeClosed(0, 10000000000L)
                .sequential()
                .reduce(0, Long::sum);
        System.out.println(sum1);
        Instant end1 = Instant.now();// 结束时间戳
        System.out.println("串行流耗费时间为：" + Duration.between(start1, end1).toMillis());// 单位：毫秒

        /**
         * 并行流：parallel()
         */
        Instant start2 = Instant.now();
        long sum2 = LongStream.rangeClosed(0, 10000000000L)
                .parallel()
                .reduce(0, Long::sum);
        System.out.println(sum2);
        Instant end2 = Instant.now();
        System.out.println("并行流耗费时间为：" + Duration.between(start2, end2).toMillis());
    }

}
