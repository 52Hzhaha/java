package com.zxj.package9;

import org.junit.Test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 时间日期格式化
 */
public class TestDateTimeFormatter {
    /**
     * ISO-8601指定的格式化标准
     */
    @Test
    public void test1(){
        DateTimeFormatter dateTimeFormatter1 = DateTimeFormatter.ISO_DATE_TIME;
        LocalDateTime localDateTime = LocalDateTime.now();

        String strDate1 = localDateTime.format(dateTimeFormatter1);
        System.out.println(strDate1);// 2020-06-26T07:40:08.345

        /**
         * 使用ISO-8601指定的格式化标准指定格式：DateTimeFormatter.ISO_DATE，只要时间日期中的日期（即Date，包含年月日）。
         */
        DateTimeFormatter dateTimeFormatter2 = DateTimeFormatter.ISO_DATE;
        String strDate2 = localDateTime.format(dateTimeFormatter2);
        System.out.println(strDate2);// 2020-06-26
    }


    /**
     * 当我们不想使用ISO-8601指定的格式化标准，只想使用自己指定的格式化标准，
     * 此时可以调用DateTimeFormatter的ofPattern()方法指定我们想要的格式。
     */
    @Test
    public void test2(){
        LocalDateTime localDateTime1 = LocalDateTime.now();
        System.out.println(localDateTime1);// 2020-06-26T07:43:24.483

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日 HH:mm:ss");
        String strDate1 = dateTimeFormatter.format(localDateTime1);
        System.out.println(strDate1);// 2020年06月26日 07:43:24

        // 将strDate1解析回LocalDateTime格式
        LocalDateTime localDateTime2 = localDateTime1.parse(strDate1, dateTimeFormatter);
        System.out.println(localDateTime2);// 2020-06-26T07:43:24
    }


}
