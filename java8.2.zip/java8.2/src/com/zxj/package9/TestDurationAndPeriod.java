package com.zxj.package9;

import org.junit.Test;

import java.time.*;

/**
 *
 * Duration：计算两个时间之间的间隔
 * Period：计算两个日期之间的间隔
 */
public class TestDurationAndPeriod {

    /**
     * 使用Duration的between()方法计算两个Instant时间的间隔
     */
    @Test
    public void test1(){
        Instant instant1 = Instant.now();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Instant instant2 = Instant.now();
        Duration duration = Duration.between(instant1, instant2);
        System.out.println(duration);// 输出是PT1S，是IOS-8601的显示格式，但是我们想要间隔使用多少毫秒、多少秒表示的，应该怎么办？
        /**
         * Duration的toMillis()：将间隔转换成毫秒数
         */
        long millis = duration.toMillis();
        System.out.println("两个时间的间隔毫秒数：" + millis + "毫秒");
    }

    /**
     * 使用Duration的between()方法计算两个LocalTime时间的间隔
     */
    @Test
    public void test2(){
        LocalTime localTime1 = LocalTime.now();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        LocalTime localTime2 = LocalTime.now();
        long millis = Duration.between(localTime1, localTime2).toMillis();
        System.out.println("两个时间的间隔毫秒数：" + millis + "毫秒");
    }

    /**
     * 使用Period的between()方法计算两个LocalDate日期的间隔
     */
    @Test
    public void test3(){
        LocalDate localDate1 = LocalDate.of(2015, 1, 1);
        LocalDate localDate2 = LocalDate.now();
        Period period = Period.between(localDate1, localDate2);
        System.out.println(period);// 打印P5Y5M24D，是IOS-8601的显示格式，5Y表示相差5年，5M表示相差5个月，24D表示相差24天，总共就是相差5年5个月24天

        int year = period.getYears();//Period的getYears()方法，获取两个日期之间相差的年数。
        int month = period.getMonths();//Period的getMonths()方法，获取两个日期之间相差的月数。
        int day = period.getDays();//Period的getDays()方法，获取两个日期之间相差的天数。
        System.out.println("两个日期之间相差：" + year + "年" + month + "月" + day + "天");

    }
}
