package com.zxj.package9;

import org.junit.Test;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

/**
 * Instant
 */
public class TestInstant {
    /**
     * 创建一个Instant
     */
    @Test
    public void test1() {
        Instant instant = Instant.now();
        /**
         * 打印结果：2020-06-25T13:32:27.183Z
         *
         * 问题：我们发现当前计算机显示时间是2020-06-25T21:32:27，但打印出来的怎么是2020-06-25T13:32:27，
         * 差了8个小时。
         *
         * 答案：因为Instant默认获取UTC时区（本初子午线，即零度经线）的时间，所以打印的是美国时间，
         * 我们中国和美国相差8个小时，为了获取符合我们中国的时间，需要对Instant获取到的时间做一个
         * 偏移量运算，对其加上8个小时。
         */
        System.out.println(instant);

        /**
         * 对Instant获取到的时间做一个偏移量运算，对其加上8个小时。
         *
         * 打印：2020-06-25T21:39:15.906+08:00
         * 意思是，当前时间是2020-06-25T21:39:15.906，后面的+08:00，表示当前时间是在UTC时间基础
         * 上加8小时后得到的。
         */
        OffsetDateTime offsetDateTime = instant.atOffset(ZoneOffset.ofHours(8));
        System.out.println(offsetDateTime);
    }

    /**
     * 我们发现上面Instant.now()获取到的是一个时间，如果我们想要的是一个时间戳，即当前系统时间减去Unix
     * 元年之间的毫秒数，应该怎么办？
     *
     * 调用Instant的toEpochMilli()
     */
    @Test
    public void test2() {
        Instant instant = Instant.now();
        long epochMilli = instant.toEpochMilli();
        System.out.println("时间戳：" + epochMilli);// 打印 1593092691179

    }

    /**
     * 使用Instant在Unix元年的基础上进行时间的增减操作
     */
    @Test
    public void test3() {
        /**
         * 在Unix元年的基础上，加上一秒
         * 元年是：1970-01-01T00:00:00Z，加上一秒是1970-01-01T00:01:00Z
         */
        Instant instant = Instant.ofEpochSecond(60);
        System.out.println(instant);
    }

}
