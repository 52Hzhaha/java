package com.zxj.package9;

import org.junit.Test;

import java.time.LocalDateTime;

/**
 * LocalDateTime
 */
public class TestLocalDateTime {
    /**
     * 使用LocalDateTime的now()方法，创建一个时间（包含年月日时分秒）。
     */
    @Test
    public void test1() {
        LocalDateTime localDateTime = LocalDateTime.now();// 获取当前系统时间，包含年月日时分秒
        System.out.println(localDateTime);// 输出时间格式，2020-06-25T21:06:57.963，符合ISO-8601标准
    }

    /**
     * 使用LocalDateTime的of(int year, Month month, int dayOfMonth, int hour, int minute, int second)方法，
     * 创建一个时间，在of方法中可以指定创建时间的年（year）、月（month）、日（dayOfMonth）、时（hour）、分（minute）、秒（second）
     */
    @Test
    public void test2(){
        LocalDateTime localDateTime = LocalDateTime.of(2015, 10, 19, 13, 22, 33);
        System.out.println(localDateTime);
    }

    /**
     * 对时间做运算，比如加上两天、加上两年等
     */
    @Test
    public void test3(){
        LocalDateTime localDateTime = LocalDateTime.now();// 当前系统时间
        /**
         * LocalDateTime包含很多时间运算操作
         * plusYears(long years)：加上几年
         * plusMonths(long months) ：加上几个月
         * plusWeeks(long weeks)：加上几周
         * 。。。
         *
         * minusYears(long years)：减去几年
         * minusMonths(long months)：减去几个月
         * minusWeeks(long weeks)：减去几周
         */
        LocalDateTime newLocalDateTime = localDateTime.plusYears(2);
        System.out.println(newLocalDateTime);

    }

    /**
     * LocalDateTime里的get方法，可以查看当前时间的年、月、日等分别是多少
     * getYear()：获取年
     * getMonthValue()：获取月
     * getMonth()：返回Month对象，再调用Month的value()方法，获取月
     * getDayOfMonth()：获取天
     * getHour()：获取时
     * getMinute()：获取分
     * getSecond()：获取秒
     */
    @Test
    public void test4(){
        LocalDateTime localDateTime = LocalDateTime.now();// 当前系统时间
        int year = localDateTime.getYear();
        System.out.println("年：" + year);
        int month1 = localDateTime.getMonthValue();
        System.out.println("月：" + month1);
        int month2 = localDateTime.getMonth().getValue();
        System.out.println("月：" + month2);
        int day = localDateTime.getDayOfMonth();
        System.out.println("日：" + day);
        int hour = localDateTime.getHour();
        System.out.println("时：" + hour);
        int minute = localDateTime.getMinute();
        System.out.println("分：" + minute);
        int second = localDateTime.getSecond();
        System.out.println("秒：" + second);
    }
}
