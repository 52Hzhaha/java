package com.zxj.package9;

import org.junit.Test;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;

public class TestTemporalAdjuster {
    /**
     * 使用java8提供的时间校正器
     * 获取当前日期后面的第一个周日是哪一天
     */
    @Test
    public void test1(){
        LocalDate localDate = LocalDate.now();//当前时间，2020-06-26
        System.out.println(localDate);
        LocalDate newLocalDate = localDate.with(TemporalAdjusters.next(DayOfWeek.SUNDAY));
        System.out.println(newLocalDate);
    }

    /**
     * 自定义时间校正器
     * with(TemporalAdjuster adjuster)，with方法的参数是TemporalAdjuster，
     * 如果我们想获取当前日期后面的第一个工作日，发现java8没有提供获取下一个工作日
     * 的时间校正器实例，所以我们可以自定义一个时间校正器。
     * TemporalAdjuster是个函数式接口，我们可以用匿名内部类来自定义
     */
    @Test
    public void test2(){
        LocalDate localDate = LocalDate.now();

        // 自定义时间校正器
        TemporalAdjuster temporalAdjuster = new TemporalAdjuster() {
            @Override
            public Temporal adjustInto(Temporal temporal) {
                LocalDate localDate = (LocalDate) temporal;
                DayOfWeek dayOfWeek = localDate.getDayOfWeek();// 获取当前日期在一周中的周几
                // 如果当前日期在周五，它后面的第一个工作日是周一，所以加上三天。
                if(dayOfWeek.equals(DayOfWeek.FRIDAY)){
                    return localDate.plusDays(3);
                }else if(dayOfWeek.equals(DayOfWeek.SATURDAY)){
                    // 如果当前日期在周六，它后面的第一个工作日是周一，所以加上两天。
                    return localDate.plusDays(2);
                }else{
                    // 其他情况，都加上一天。比如当前日期是周一到周四，后面的第一个工作日就是第二天，所以加上一天。
                    // 如果当前日期是周日，后面的第一个工作日是周一，也是加上一天。
                    return localDate.plusDays(1);
                }
            }
        };

        System.out.println(localDate);// 2020-06-26
        LocalDate newLocalDate = localDate.with(temporalAdjuster);
        System.out.println(newLocalDate);// 2020-06-29
    }

    /**
     * 将当前日期中的天指定为10
     */
    @Test
    public void test3(){
        LocalDate localDate = LocalDate.now();//当前时间，2020-06-26
        System.out.println(localDate);
        LocalDate newLocalDate = localDate.withDayOfMonth(10);
        System.out.println(newLocalDate);// 2020-06-10
    }

}
