package com.zxj.package9;

import org.junit.Test;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Set;

/**
 * 时区的处理
 */
public class TestZone {

    /**
     * 获取所有的时区
     */
    @Test
    public void test1(){
        Set<String> set = ZoneId.getAvailableZoneIds();
        set.forEach(System.out::println);
    }

    /**
     * 创建一个时区是在"Europe/Tallinn"的时间
     * LocalDateTime，只是把在指定时区的时间打印出来，不打印当前系统所在时区和指定时区之间相差的时间间隔，
     * 还有指定时区的信息
     */
    @Test
    public void test2(){
        ZoneId zoneId = ZoneId.of("Europe/Tallinn");
        System.out.println(zoneId);

        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println(localDateTime);// 当前计算机系统时间：2020-06-26T08:09:29.709

        LocalDateTime localDateTimeWithZone = LocalDateTime.now(ZoneId.of("Europe/Tallinn"));
        System.out.println(localDateTimeWithZone);// 指定时区的时间：2020-06-26T03:09:29.710
    }

    /**
     * 创建一个时区是在"Europe/Tallinn"的时间
     */
    @Test
    public void test3(){
        LocalDateTime localDateTime = LocalDateTime.now();
        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of("Europe/Tallinn"));
        /**
         * 打印结果：2020-06-26T08:14:16.783+03:00[Europe/Tallinn]
         * +03:00：表示当前计算机系统所在时区和指定时区之间相差3个小时
         * [Europe/Tallinn]：指定的时区的信息
         */
        System.out.println(zonedDateTime);
    }


}
