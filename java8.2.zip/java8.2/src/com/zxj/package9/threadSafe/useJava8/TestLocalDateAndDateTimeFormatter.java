package com.zxj.package9.threadSafe.useJava8;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * 使用java8提供的线程安全的时间日期
 * API（LocalDate和DateTimeFormatter），解决线程不安全的问题
 */
public class TestLocalDateAndDateTimeFormatter {

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        // java8中，时间格式化的API，DateTimeFormatter
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");

        // java8中，日期API，LocalDate
        Callable<LocalDate> callable = new Callable<LocalDate>() {
            @Override
            public LocalDate call() throws Exception {
                return LocalDate.parse("20161218",dateTimeFormatter);// 对20161218这个日期，按照dateTimeFormatter的格式进行转换。
            }
        };

        ExecutorService pool = Executors.newFixedThreadPool(10);

        List<Future<LocalDate>> results = new ArrayList<>();

        for(int i = 0; i < 10; i++){
            results.add(pool.submit(callable));
        }

        for(Future<LocalDate> future : results){
            System.out.println(future.get());
        }
    }

}
