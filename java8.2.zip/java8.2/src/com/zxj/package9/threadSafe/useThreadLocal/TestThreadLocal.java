package com.zxj.package9.threadSafe.useThreadLocal;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.*;

/**
 * 解决SimpleDateFormat线程不安全的问题
 * 1、上锁。2、把SimpleDateFormat放到ThreadLocal里。
 * 我们这里使用第2中方法
 */
public class TestThreadLocal {

    private static final ThreadLocal<SimpleDateFormat> df = new ThreadLocal<SimpleDateFormat>(){
        @Override
        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat("yyyyMMdd");
        }
    };

    // 将String类型的时间转换成Date格式
    private static Date convert(String date) throws ParseException {
        return df.get().parse(date);
    }

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        // 线程
        Callable<Date> callable = new Callable<Date>() {
            @Override
            public Date call() throws Exception {
                return convert("20161218");
            }
        };

        ExecutorService pool = Executors.newFixedThreadPool(10);// 线程池

        List<Future<Date>> results = new ArrayList<>();

        // callable执行10次，并将10次执行的结果加入到集合中。
        for(int i = 0; i < 10; i++){
            results.add(pool.submit(callable));
        }

        /**
         * 我们发现10次的时间一样，都是Sun Dec 18 00:00:00 CST 2016
         */
        for(Future<Date> future : results){
            System.out.println(future.get());
        }
        /**
         * 注意及时关闭线程池，否则程序无限执行下去，打印一大堆的Sun Dec 18 00:00:00 CST 2016，大于10个
         */
        pool.shutdown();
    }
}
