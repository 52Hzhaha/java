package com.zxj.package9.threadUnsafe;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.*;

/**
 * SimpleDateFormat：线程不安全
 */
public class TestSimpleDateFormat {

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");

        // 线程
        Callable<Date> callable = new Callable<Date>() {
            @Override
            public Date call() throws Exception {
                return simpleDateFormat.parse("20161218");
            }
        };

        ExecutorService pool = Executors.newFixedThreadPool(10);// 线程池

        List<Future<Date>> results = new ArrayList<>();

        // callable执行10次，并将10次执行的结果加入到集合中。
        for(int i = 0; i < 10; i++){
            results.add(pool.submit(callable));
        }

        /**
         * 我们发现结果有两种情况，第一种运气比较好，10次的时间都不一样，
         * 第二种由于时间不断变化，时间解析不出来，抛异常
         */
        for(Future<Date> future : results){
            System.out.println(future.get());
        }

        pool.shutdown();

    }

}
